import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Cities, States, datatype, student, users } from '../type';
import {
  FormGroup,
  FormControl,
  FormArray,
  Validators,
} from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  constructor(private serv: ServiceService) {


  }

  studentdata:Array<student>=[];
  studentForm!: FormGroup;

  crede:Array<users>=[]
  cities:Array<Cities>=[];
  states: Array<States> = [];

  data: Array<datatype> = [];

  ngOnInit(): void {


    this.data = this.serv.data;

    this.cities=this.serv.getcitiies();
    this.states=this.serv.states;
    this.crede=this.serv.credentials;

    this.studentForm = new FormGroup({
      Fullname: new FormGroup({
        Firstname: new FormControl('', [Validators.required]),
        Middlename: new FormControl('', [Validators.required]),
        Lastname: new FormControl('', [Validators.required]),
      }),

      Email: new FormControl('', [Validators.required,Validators.email]),



      Address: new FormGroup({
        Building: new FormControl('', [Validators.required]),
        Area: new FormControl('', [Validators.required]),
        State: new FormControl('', [Validators.required]),
        City: new FormControl('', [Validators.required]),
      }),

      Gender: new FormControl('', [Validators.required]),

      // Skills: new FormArray([
      //   new FormControl('', [Validators.required])]),

      skills:new FormControl('', [Validators.required]),

      EducationDetails: new FormGroup({
        Tenth: new FormGroup({
          Marks: new FormControl('', [Validators.required]),
          Grade: new FormControl('', [Validators.required]),
          YearofPassing: new FormControl('', [Validators.required]),
        }),

        Twelth: new FormGroup({
          Marks: new FormControl('', [Validators.required]),
          Grade: new FormControl('', [Validators.required]),
          YearofPassing: new FormControl('', [Validators.required]),
        }),

        Deggree: new FormGroup({
          Marks: new FormControl('', [Validators.required]),
          Grade: new FormControl('', [Validators.required]),
          YearofPassing: new FormControl('', [Validators.required]),
        }),
      }),
    });


  }


  submit(){

    alert()
    this.studentdata.push(this.studentForm.value);
    console.log(this.studentdata);


  }

  get Skillsarr(){
    return this.studentForm.get('skills') as FormArray
  }
//   clickme(){
// this.serv.getstate()
//   }


}
