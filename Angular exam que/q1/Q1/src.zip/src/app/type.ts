export interface datatype {
  states: States[]
  Cities:Cities[]
  users:users[]


}

export interface States {
  StateID: number
  StateName: string
}

export interface Cities {
  CityID: number
  Name: string
  StateID: string
}

export interface users {
  userName: string

  password: string

  role: string
}





export interface student
{
  Fullname:Fullname,
  Email:string,
  Address:Address,
  Gender:string,
  // skills:string[],
  Skills:string,
  Educatiodetails:Educationdetails
}


export interface Fullname{

  Firstname:string,
  Middlename:string,
  Lastname:string,


}


export interface Address{

  Building:string,
  Area:string,
  State:string,
  City:string,


}


export interface Educationdetails
{
  Tenth:Details,
  Twelth:Details,

  degree:Details,



}


export interface Details
{
  Marks:string,
  Grade:string,
  Yearofpassing:string,


}
