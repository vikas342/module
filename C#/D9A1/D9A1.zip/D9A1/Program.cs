﻿
using D9A1.Models;
using System;
using System.IO;
using System.Reflection;
using System.Text.Json;

using D9A1.Models;

namespace D9A1

{
    internal class Program
    {
        static void Main(string[] args)
        {
            FileStream fs = new FileStream(@"C:\\Users\\vikas.sonwane\\Desktop\\module\\C#\\D9A1\\D9A1\\movie.json",FileMode.Open,FileAccess.Read);


            StreamReader sr = new StreamReader(fs);
            string line= sr.ReadToEnd();

            var data = JsonSerializer.Deserialize<MoviesData[]>(line);

            var list= data.ToList();
           //  Console.WriteLine(data);

            foreach (var item in data)
            {
                Console.WriteLine(item.Details.DirectorName );
            }


            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine();

            Console.Write("Enter directer's name:");
            string inp1 = Convert.ToString(Console.ReadLine());

            var found1 = list.FindAll(x=> x.Details.DirectorName== inp1);
            Console.WriteLine();
            Console.WriteLine("Directors Movies");
            Console.WriteLine();

            foreach (var item in found1)
            {
                Console.WriteLine(item.MovieName);

            }



            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();


            Console.WriteLine("Printing Movies in which Director is Working as Actor:");
            Console.WriteLine();
            Console.WriteLine();

            var found2 = list.FindAll(x => x.Details.DirectorName == x.Details.ActorsNames[0]);
            Console.WriteLine();
            Console.WriteLine();

            foreach (var item in found2)
            {
                Console.WriteLine(item.MovieName);

            }


        }
    }
}